package com.example.gohike;

public class GabungTim {
}
