package com.example.gohike;

public class ListData {
    String name, pembawaan, pengertian;
    int image;

    public ListData(String name, String pembawaan, String pengertian, int image) {
        this.name = name;
        this.pembawaan = pembawaan;
        this.pengertian = pengertian;
        this.image = image;
    }
}

